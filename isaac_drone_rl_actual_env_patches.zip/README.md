# Isaac Drone RL patched files

This bundle patches your actual uploaded files and includes clean Docker files.

Files:
- `isaac_drone_env.py`
- `multimodal_drone_env.py`
- `isaac_drone_env.py.diff`
- `multimodal_drone_env.py.diff`
- `Dockerfile`
- `docker-compose.yml`
- `rebuild_and_test.sh`

Main Python fix:
- TorchRL wrapper `_reset()` now detects `select_reset_only=True`.
- During TorchRL selective resets, it no longer calls `self._isaac_env.reset()`.
- Instead, it returns the latest IsaacLab observation and clears done flags.
- Both wrappers now include the `truncated` key in reset and step outputs.

Docker fixes:
- Pins Isaac Sim 5.1.0 and Isaac Lab v2.3.0.
- Uses a unique `drone-rl:isaac51-lab230` tag.
- Uses one clean Compose GPU config.
- Starts at `--num-envs 8` for smoke testing.

How to apply:
1. Back up your current files.
2. Copy `Dockerfile`, `docker-compose.yml`, `isaac_drone_env.py`, and `multimodal_drone_env.py` into your project root.
3. Run `chmod +x rebuild_and_test.sh`.
4. Run `./rebuild_and_test.sh`.
5. If stable, raise `--num-envs` from 8 to 16, 32, then 64.
