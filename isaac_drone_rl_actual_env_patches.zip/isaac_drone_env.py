"""
isaac_drone_env.py
==================
A photorealistic visual drone RL environment built on Isaac Lab + Isaac Sim.

Key differences vs a basic PyBullet env:
  - Observations are real RTX-rendered RGB tensors — never leave the GPU
  - Domain randomization uses omni.replicator (the same tool Pixar uses)
  - Hundreds of parallel environments run simultaneously on one GPU
  - Physics runs at 200 Hz; policy runs at 50 Hz (4:1 decimation)

Run inside the container:
  /isaac-sim/python.sh isaac_drone_env.py

Architecture:
  Isaac Sim (renderer + physics)
       ↓  GPU tensor (no CPU copy)
  CNN Feature Extractor
       ↓  latent vector
  PPO Policy Head
       ↓  velocity command
  Isaac Sim (apply action)
"""

from __future__ import annotations

# ── Isaac Lab / Omniverse imports ──────────────────────────────────────────
# These are only resolvable inside the Isaac Sim container
try:
    import isaaclab.sim as sim_utils
    from isaaclab.assets import Articulation, ArticulationCfg
    from isaaclab.envs import DirectRLEnv, DirectRLEnvCfg
    from isaaclab.scene import InteractiveSceneCfg
    from isaaclab.sensors import Camera, CameraCfg
    from isaaclab.sim import SimulationCfg
    from isaaclab.utils import configclass
    from isaaclab.utils.math import subtract_frame_transforms
    from isaaclab_assets import CRAZYFLIE_CFG
    ISAAC_AVAILABLE = True
except ImportError as exc:
    ISAAC_AVAILABLE = False
    print(f"[WARN] Isaac Lab not found — running in stub/test mode: {exc}")

try:
    import omni.replicator.core as rep
    REPLICATOR_AVAILABLE = True
except ImportError:
    rep = None
    REPLICATOR_AVAILABLE = False

import torch
import numpy as np
from dataclasses import dataclass, field
from typing import Tuple


# =============================================================================
# Scene & Simulation Configuration
# =============================================================================
@configclass
class VisualDroneSceneCfg(InteractiveSceneCfg):
    """
    Defines what objects exist in the scene.
    Isaac Lab builds USD (Pixar Universal Scene Description) stages from this.
    """
    pass


@configclass
class VisualDroneEnvCfg(DirectRLEnvCfg):
    """Top-level environment configuration."""

    # Simulation
    sim: SimulationCfg = SimulationCfg(
        dt=1 / 200,           # Physics at 200 Hz
        render_interval=4,    # Render (and step policy) at 50 Hz
    )
    decimation: int = 4

    scene: VisualDroneSceneCfg = VisualDroneSceneCfg(
        num_envs=64,           # 64 parallel drones — tune to VRAM
        env_spacing=8.0,
    )

    # Drone asset — use Isaac Lab's packaged Crazyflie config for this version.
    drone: ArticulationCfg = CRAZYFLIE_CFG.replace(
        prim_path="/World/envs/env_.*/Drone",
    )

    # Forward-facing RGB camera mounted on the drone.
    camera: CameraCfg = CameraCfg(
        prim_path="/World/envs/env_.*/Drone/Camera",
        update_period=0.02,           # 50 Hz
        height=84,
        width=84,
        data_types=["rgb"],           # pure RGB — no depth needed
        spawn=sim_utils.PinholeCameraCfg(
            focal_length=24.0,
            focus_distance=400.0,
            horizontal_aperture=20.955,
            clipping_range=(0.1, 100.0),
        ),
        offset=CameraCfg.OffsetCfg(
            pos=(0.1, 0.0, 0.05),
            rot=(0.0, 0.1305, 0.0, 0.9914),  # ~15° downward tilt
            convention="ros",
        ),
    )

    # Observation: raw (84, 84, 3) RGB image → flattened for SB3 CNN
    observation_space: int = 84 * 84 * 3

    # Action: [vx, vy, vz, yaw_rate] normalized to [-1, 1]
    action_space: int = 4

    # Episode
    episode_length_s: float = 10.0       # seconds
    max_episode_steps: int = 500

    # Reward weights
    reward_approach: float = 5.0
    reward_alive: float = 0.1
    reward_reach: float = 100.0
    penalty_crash: float = -100.0
    penalty_boundary: float = -50.0

    # Domain randomization
    enable_domain_rand: bool = True


# =============================================================================
# Domain Randomization via NVIDIA Omniverse Replicator
# =============================================================================
class DomainRandomizer:
    """
    Uses omni.replicator to randomize the scene every N steps.
    Replicator is a production-grade tool — the same pipeline used in
    synthetic data generation for robotics at NVIDIA.
    """

    def __init__(self, scene_cfg: VisualDroneSceneCfg):
        self.cfg = scene_cfg
        self._graph = None

    def build_randomization_graph(self):
        """
        Build the Replicator graph ONCE before training starts.
        It will execute on every trigger (every reset or every K steps).
        """
        if not ISAAC_AVAILABLE or not REPLICATOR_AVAILABLE:
            return

        try:
            with rep.new_layer():

                # ── Lighting randomization ───────────────────────────────────
                # Replicator's Python API has changed across Isaac releases, so
                # keep this optional: training should still run without it.
                dome = rep.get.prim("/World/DomeLight")
                with rep.trigger.on_custom_event(event_name="randomize"):
                    with dome:
                        rep.modify.attribute(
                            "intensity",
                            rep.distribution.uniform(500, 4000),
                        )
                        rep.modify.attribute(
                            "color",
                            rep.distribution.uniform(
                                (0.8, 0.7, 0.5),
                                (1.0, 1.0, 1.2),
                            ),
                        )

                sun = rep.get.prim("/World/SunLight")
                with sun:
                    rep.modify.pose(
                        rotation=rep.distribution.uniform(
                            (-90, -180, 0),
                            (0, 180, 0),
                        )
                    )

                ground = rep.get.prim("/World/GroundPlane")
                with ground:
                    rep.randomizer.color(
                        colors=rep.distribution.uniform(
                            (0.1, 0.1, 0.1),
                            (0.9, 0.9, 0.9),
                        )
                    )

                cameras = rep.get.camera()
                with cameras:
                    rep.modify.attribute(
                        "focalLength",
                        rep.distribution.uniform(18.0, 35.0),
                    )

            self._graph = True
        except Exception as exc:
            self._graph = None
            print(f"[WARN] Domain randomization disabled: {exc}")

    def trigger(self):
        """Call at the start of each episode to re-randomize the scene."""
        if not (ISAAC_AVAILABLE and REPLICATOR_AVAILABLE and self._graph is not None):
            return
        try:
            rep.utils.send_og_event(event_name="randomize")
        except Exception as exc:
            self._graph = None
            print(f"[WARN] Domain randomization trigger disabled: {exc}")


# =============================================================================
# Main Environment Class
# =============================================================================
class VisualDroneEnv(DirectRLEnv):
    """
    The core RL environment. Isaac Lab's DirectRLEnv handles the simulation
    loop, parallel env management, and tensor device placement.
    We implement the game logic: observations, rewards, resets.
    """

    cfg: VisualDroneEnvCfg

    def __init__(self, cfg: VisualDroneEnvCfg, **kwargs):
        super().__init__(cfg, **kwargs)

        # Domain randomizer
        self._domain_rand = DomainRandomizer(cfg.scene)
        if cfg.enable_domain_rand:
            self._domain_rand.build_randomization_graph()

        # Cached tensors (all on GPU — never touch CPU during training)
        self._drone_pos = torch.zeros(self.num_envs, 3, device=self.device)
        self._drone_vel = torch.zeros(self.num_envs, 3, device=self.device)
        self._target_pos = torch.zeros(self.num_envs, 3, device=self.device)
        self._prev_dist = torch.zeros(self.num_envs, device=self.device)

        # Workspace bounds [x, y, z]
        self._bounds = torch.tensor([5.0, 5.0, 4.0], device=self.device)

    # -------------------------------------------------------------------------
    # Scene setup (called once by Isaac Lab)
    # -------------------------------------------------------------------------
    def _setup_scene(self):
        self._drone = Articulation(self.cfg.drone)
        self._camera = Camera(self.cfg.camera)
        self.scene.articulations["drone"] = self._drone
        self.scene.sensors["camera"] = self._camera

        # Lighting and ground
        ground_cfg = sim_utils.GroundPlaneCfg()
        ground_cfg.func("/World/ground", ground_cfg)
        light_cfg = sim_utils.DomeLightCfg(intensity=2000.0, color=(0.75, 0.75, 0.75))
        light_cfg.func("/World/Light", light_cfg)

        # Clone environments (Isaac Lab tiles them in a grid automatically)
        self.scene.clone_environments(copy_from_source=False)
        self.scene.filter_collisions(global_prim_paths=[])

    # -------------------------------------------------------------------------
    # Observations — raw GPU image tensor
    # -------------------------------------------------------------------------
    def _get_observations(self) -> dict:
        """
        Pulls the (N, H, W, 3) RGB tensor directly off the GPU.
        The CNN feature extractor in train_visual_rl.py consumes this.
        """
        # camera.data.output["rgb"] is shape (num_envs, 84, 84, 4) RGBA uint8
        rgba = self._camera.data.output["rgb"]          # GPU tensor

        # Drop alpha channel → (num_envs, 84, 84, 3)
        rgb = rgba[..., :3].float() / 255.0             # Normalize to [0, 1]

        # SB3 expects (N, C, H, W) — permute from (N, H, W, C)
        rgb = rgb.permute(0, 3, 1, 2).contiguous()     # (N, 3, 84, 84)

        return {"policy": rgb}

    # -------------------------------------------------------------------------
    # Actions — apply velocity commands to the drone
    # -------------------------------------------------------------------------
    def _pre_physics_step(self, actions: torch.Tensor):
        """
        Convert normalized action [-1,1] to velocity setpoints.
        A real drone's flight controller (PX4/ArduPilot) handles the
        low-level motor mixing — we command at the velocity level.
        """
        max_vel = torch.tensor([3.0, 3.0, 2.0, 1.5], device=self.device)
        velocity_cmd = actions * max_vel

        # Apply as external force (simplified model — replace with
        # proper rotor physics for higher fidelity)
        vx, vy, vz, _ = velocity_cmd[:, 0], velocity_cmd[:, 1], \
                         velocity_cmd[:, 2], velocity_cmd[:, 3]

        forces = torch.stack([vx, vy, vz], dim=1) * 1.5  # proportional thrust
        self._drone.set_external_force_and_torque(
            forces=forces.unsqueeze(1),
            torques=torch.zeros_like(forces).unsqueeze(1),
        )

    def _apply_action(self):
        self._drone.write_data_to_sim()

    # -------------------------------------------------------------------------
    # Rewards
    # -------------------------------------------------------------------------
    def _get_rewards(self) -> torch.Tensor:
        self._drone_pos = self._drone.data.root_pos_w[:, :3]
        dist = torch.norm(self._target_pos - self._drone_pos, dim=1)

        # Dense: reward for getting closer
        approach = (self._prev_dist - dist) * self.cfg.reward_approach

        # Alive bonus — keeps the drone in the air
        alive = torch.ones(self.num_envs, device=self.device) * self.cfg.reward_alive

        # Reach bonus
        reached = (dist < 0.3).float() * self.cfg.reward_reach

        # Crash penalty
        crashed = (self._drone_pos[:, 2] < 0.1).float() * abs(self.cfg.penalty_crash)

        rewards = approach + alive + reached - crashed
        self._prev_dist = dist
        return rewards

    # -------------------------------------------------------------------------
    # Termination conditions
    # -------------------------------------------------------------------------
    def _get_dones(self) -> tuple[torch.Tensor, torch.Tensor]:
        terminated = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        truncated = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)

        # Crash: altitude below 10 cm
        terminated |= self._drone_pos[:, 2] < 0.1

        # Out of bounds
        out = (self._drone_pos.abs() > self._bounds).any(dim=1)
        terminated |= out

        # Target reached
        dist = torch.norm(self._target_pos - self._drone_pos, dim=1)
        terminated |= dist < 0.3

        # Time limit
        truncated |= self.episode_length_buf >= self.cfg.max_episode_steps
        return terminated, truncated

    # -------------------------------------------------------------------------
    # Reset
    # -------------------------------------------------------------------------
    def _reset_idx(self, env_ids: torch.Tensor):
        if len(env_ids) == 0:
            return

        # Trigger domain randomization for resetting envs
        if self.cfg.enable_domain_rand:
            self._domain_rand.trigger()

        # Randomize drone start position
        start_pos = torch.zeros(len(env_ids), 3, device=self.device)
        start_pos[:, :2] = torch.rand(len(env_ids), 2, device=self.device) * 2 - 1
        start_pos[:, 2] = torch.rand(len(env_ids), device=self.device) * 1.5 + 1.0

        # Randomize target position (within bounds, not too close to start)
        self._target_pos[env_ids, :2] = (
            torch.rand(len(env_ids), 2, device=self.device) * 6 - 3
        )
        self._target_pos[env_ids, 2] = (
            torch.rand(len(env_ids), device=self.device) * 2 + 0.5
        )

        # Reset drone state
        default_root_state = self._drone.data.default_root_state[env_ids].clone()
        default_root_state[:, :3] = start_pos
        self._drone.write_root_state_to_sim(default_root_state, env_ids=env_ids)

        # Initialize prev distance
        self._prev_dist[env_ids] = torch.norm(
            self._target_pos[env_ids] - start_pos, dim=1
        )

        self._drone.reset(env_ids)
        super()._reset_idx(env_ids)


# =============================================================================
# TorchRL EnvBase Wrapper — GPU-native, TensorDict I/O
# =============================================================================
try:
    from torchrl.envs import EnvBase
    from tensordict import TensorDict
    try:
        from torchrl.data import (
            CompositeSpec,
            BoundedTensorSpec,
            UnboundedContinuousTensorSpec,
        )
    except ImportError:
        from torchrl.data.tensor_specs import (
            Composite as CompositeSpec,
            Bounded as BoundedTensorSpec,
            UnboundedContinuous as UnboundedContinuousTensorSpec,
        )
    TORCHRL_AVAILABLE = True
except ImportError as exc:
    TORCHRL_IMPORT_ERROR = exc
    TORCHRL_AVAILABLE = False


class IsaacDroneTorchRLWrapper(EnvBase if TORCHRL_AVAILABLE else object):
    """
    Wraps VisualDroneEnv as a TorchRL EnvBase environment.

    All tensors stay on GPU — no CPU/numpy roundtrip (unlike the old SB3
    wrapper). The SyncDataCollector and ClipPPOLoss consume TensorDicts
    produced by this wrapper directly.

    Observation: td["observation"] → (num_envs, 3, 84, 84) float32 [0,1]
    Action:      td["action"]     → (num_envs, 4) float32 [-1,1]
    """

    def __init__(self, isaac_env: "VisualDroneEnv", device=None, **kwargs):
        if not TORCHRL_AVAILABLE:
            raise ImportError("TorchRL is required for IsaacDroneTorchRLWrapper") from TORCHRL_IMPORT_ERROR

        self._isaac_env = isaac_env
        _device = device or isaac_env.device
        super().__init__(
            device=_device,
            batch_size=torch.Size([isaac_env.num_envs]),
            **kwargs,
        )

        # ── Define specs ─────────────────────────────────────────────────
        H = W = 84
        batch_shape = torch.Size([isaac_env.num_envs])
        self.observation_spec = CompositeSpec(
            observation=BoundedTensorSpec(
                low=0.0, high=1.0,
                shape=(*batch_shape, 3, H, W),
                dtype=torch.float32,
                device=_device,
            ),
            shape=batch_shape,
        )
        self.action_spec = BoundedTensorSpec(
            low=-1.0, high=1.0,
            shape=(*batch_shape, 4),
            dtype=torch.float32,
            device=_device,
        )
        self.reward_spec = UnboundedContinuousTensorSpec(
            shape=(*batch_shape, 1),
            dtype=torch.float32,
            device=_device,
        )

    def _reset(self, tensordict=None, **kwargs) -> TensorDict:
        """
        Reset wrapper for TorchRL.

        TorchRL calls reset(select_reset_only=True) after done=True during
        collection. The IsaacLab DirectRLEnv has already handled per-env resets
        inside step(), so forcing another full self._isaac_env.reset() here can
        reset camera/scene GPU buffers a second time and trigger CUDA illegal
        memory access.

        Full reset is used only for the initial reset. Selective TorchRL resets
        simply return the latest IsaacLab observation with done flags cleared.
        """
        select_reset_only = bool(kwargs.get("select_reset_only", False))

        if select_reset_only:
            obs_dict = self._isaac_env._get_observations()
        else:
            obs_dict, _ = self._isaac_env.reset()

        image = obs_dict["policy"]  # (N, 3, 84, 84)
        done_shape = (*self.batch_size, 1)
        zeros = torch.zeros(done_shape, dtype=torch.bool, device=self.device)

        return TensorDict(
            {
                "observation": image,
                "done": zeros.clone(),
                "terminated": zeros.clone(),
                "truncated": zeros.clone(),
            },
            batch_size=self.batch_size,
            device=self.device,
        )

    def _step(self, tensordict: TensorDict) -> TensorDict:
        actions = tensordict["action"]  # (N, 4) — already on GPU
        obs_dict, rewards, terminated, truncated, info = self._isaac_env.step(actions)

        image = obs_dict["policy"]  # (N, 3, 84, 84)
        done = (terminated | truncated).unsqueeze(-1)  # (N, 1)

        return TensorDict(
            {
                "observation": image,
                "reward": rewards.unsqueeze(-1),           # (N, 1)
                "done": done,
                "terminated": terminated.unsqueeze(-1),    # (N, 1)
                "truncated": truncated.unsqueeze(-1),      # (N, 1)
            },
            batch_size=self.batch_size,
            device=self.device,
        )

    def _set_seed(self, seed: int | None):
        # Isaac Lab handles seeding internally via SimulationCfg
        pass

    def close(self):
        self._isaac_env.close()


# =============================================================================
# Standalone test (run inside the container to verify the env works)
# =============================================================================
if __name__ == "__main__":
    if not ISAAC_AVAILABLE:
        print("Isaac Sim not available. Run this inside the Docker container:")
        print("  /isaac-sim/python.sh isaac_drone_env.py")
        exit(0)

    import isaaclab.sim as sim_utils
    from isaaclab.app import AppLauncher

    launcher = AppLauncher(headless=True, enable_cameras=True)
    simulation_app = launcher.app

    cfg = VisualDroneEnvCfg()
    cfg.scene.num_envs = 4
    cfg.enable_domain_rand = True

    isaac_env = VisualDroneEnv(cfg=cfg)

    # ── Test raw Isaac Lab env ───────────────────────────────────────────
    obs, _ = isaac_env.reset()
    print(f"[OK] Isaac Lab environment created")
    print(f"     Num envs     : {isaac_env.num_envs}")
    print(f"     Obs shape    : {obs['policy'].shape}")   # (4, 3, 84, 84)
    print(f"     Action space : {isaac_env.cfg.action_space}")
    print(f"     Device       : {isaac_env.device}")

    for i in range(5):
        action = torch.rand(cfg.scene.num_envs, cfg.action_space) * 2 - 1
        obs, rew, terminated, truncated, info = isaac_env.step(action.to(isaac_env.device))
        print(f"     Step {i+1} | mean reward: {rew.mean():.3f}")

    # ── Test TorchRL wrapper ─────────────────────────────────────────────
    if TORCHRL_AVAILABLE:
        rl_env = IsaacDroneTorchRLWrapper(isaac_env)
        td = rl_env.reset()
        print(f"\n[OK] TorchRL wrapper")
        print(f"     observation : {td['observation'].shape}")
        print(f"     batch_size  : {rl_env.batch_size}")
        print(f"     device      : {rl_env.device}")

        td["action"] = torch.rand(4, 4, device=rl_env.device) * 2 - 1
        td_next = rl_env.step(td)
        print(f"     step output : obs={td_next['observation'].shape} "
              f"rew={td_next['reward'].shape}")
        rl_env.close()
    else:
        print("\n[SKIP] TorchRL not installed — wrapper test skipped")

    simulation_app.close()
    print("[DONE] Environment test passed.")
