"""
multimodal_drone_env.py
=======================
Extends the visual drone environment to output BOTH a camera image
AND a structured sensor vector at every timestep.

Sensors simulated:
  - IMU         : linear acceleration + angular velocity + orientation quat
  - Barometer   : altitude + vertical velocity
  - Airspeed    : forward airspeed
  - Lidar       : 8 directional rangefinders (RayCaster sensor in Isaac Lab)
  - Navigation  : relative direction and distance to target

All sensor values are:
  1. Read from Isaac Lab sensor APIs (GPU tensors — never leave the GPU)
  2. Normalized using SensorLayout.NORM constants
  3. Injected with domain-randomized noise (simulates real sensor imperfection)
  4. Concatenated into a (N_SENSORS,) float32 vector per environment

Observation dict returned at each step:
  {
    "image"  : torch.Tensor (num_envs, 3, 84, 84)   float32 [0,1]
    "sensors": torch.Tensor (num_envs, 25)           float32 normalized
  }
"""

from __future__ import annotations

import torch
import numpy as np
from dataclasses import field
from typing import Dict

try:
    import isaaclab.sim as sim_utils
    from isaaclab.assets import Articulation, ArticulationCfg
    from isaaclab.envs import DirectRLEnv, DirectRLEnvCfg
    from isaaclab.scene import InteractiveSceneCfg
    from isaaclab.sensors import (
        Camera, CameraCfg,
        Imu, ImuCfg,
        RayCaster, RayCasterCfg,
        patterns,
    )
    from isaaclab.sim import SimulationCfg
    from isaaclab.utils import configclass
    from isaaclab.utils.math import (
        quat_rotate_inverse,
        yaw_quat,
        subtract_frame_transforms,
    )
    import omni.replicator.core as rep
    ISAAC_AVAILABLE = True
except ImportError:
    ISAAC_AVAILABLE = False
    print("[WARN] Isaac Lab not available — running in stub mode")

from multimodal_policy import SensorLayout


# =============================================================================
# Sensor Noise Configuration
# =============================================================================
@dataclass if not ISAAC_AVAILABLE else configclass
class SensorNoiseCfg:
    """
    Gaussian noise added to each sensor channel.
    These values are tuned to match real sensor datasheets:
      - MPU-6000 IMU noise floor
      - Benewake TFmini lidar noise (~3 cm at 1m)
      - MS5611 barometer noise (~10 cm)
    Domain randomization scales these by a random factor each episode.
    """
    accel_std:       float = 0.05     # m/s²  — accelerometer noise
    gyro_std:        float = 0.01     # rad/s — gyroscope noise
    baro_std:        float = 0.1      # m     — barometric altitude noise
    lidar_std:       float = 0.03     # m     — lidar range noise
    airspeed_std:    float = 0.1      # m/s   — pitot tube noise

    # Domain randomization multipliers (per episode)
    noise_scale_min: float = 0.5      # Quietest sensor config
    noise_scale_max: float = 3.0      # Worst-case noisy sensors


# =============================================================================
# Scene Configuration
# =============================================================================
try:
    @configclass
    class MultimodalDroneSceneCfg(InteractiveSceneCfg):

        ground = sim_utils.GroundPlaneCfg()
        dome_light = sim_utils.DomeLightCfg(intensity=2000.0)
        sun_light  = sim_utils.DistantLightCfg(intensity=3000.0)

        # Quadrotor articulation
        drone: ArticulationCfg = ArticulationCfg(
            prim_path="/World/envs/env_.*/Drone",
            spawn=sim_utils.UsdFileCfg(
                usd_path="{ISAAC_ASSETS}/Props/Quadrotor/quadrotor.usd",
                rigid_props=sim_utils.RigidBodyPropertiesCfg(
                    disable_gravity=False,
                    max_linear_velocity=10.0,
                    max_angular_velocity=20.0,
                ),
            ),
            init_state=ArticulationCfg.InitialStateCfg(
                pos=(0.0, 0.0, 1.5),
                rot=(1.0, 0.0, 0.0, 0.0),
            ),
        )

        # ── Sensor 1: Forward RGB Camera ──────────────────────────────────
        camera: CameraCfg = CameraCfg(
            prim_path="/World/envs/env_.*/Drone/Camera",
            update_period=0.02,
            height=84, width=84,
            data_types=["rgb"],
            spawn=sim_utils.PinholeCameraCfg(
                focal_length=24.0,
                clipping_range=(0.1, 100.0),
            ),
            offset=CameraCfg.OffsetCfg(
                pos=(0.1, 0.0, 0.05),
                rot=(0.0, 0.1305, 0.0, 0.9914),
                convention="ros",
            ),
        )

        # ── Sensor 2: IMU (accelerometer + gyroscope) ─────────────────────
        # Isaac Lab simulates IMU noise matching real sensor datasheets
        imu: ImuCfg = ImuCfg(
            prim_path="/World/envs/env_.*/Drone/Imu",
            update_period=0.005,           # 200 Hz — faster than camera
            offset=ImuCfg.OffsetCfg(
                pos=(0.0, 0.0, 0.0),       # Center of mass
            ),
            gravity_bias_range=(-0.01, 0.01),
        )

        # ── Sensor 3: Lidar Rangefinders (8 beams) ────────────────────────
        # Uses RayCaster — much cheaper than a full 3D lidar pointcloud
        # 8 horizontal beams at fixed angles for obstacle proximity
        lidar: RayCasterCfg = RayCasterCfg(
            prim_path="/World/envs/env_.*/Drone",
            update_period=0.02,
            offset=RayCasterCfg.OffsetCfg(pos=(0.0, 0.0, 0.0)),
            attach_yaw_only=True,
            pattern_cfg=patterns.GridPatternCfg(
                resolution=0.1,
                size=[0.1, 0.1],
            ),
            debug_vis=False,
            mesh_prim_paths=["/World/ground"],
            max_distance=20.0,
        )

except Exception:
    # Stub for environments without Isaac Lab
    MultimodalDroneSceneCfg = None


# =============================================================================
# Environment Configuration
# =============================================================================
try:
    @configclass
    class MultimodalDroneEnvCfg(DirectRLEnvCfg):

        sim: SimulationCfg = SimulationCfg(
            dt=1 / 200,
            render_interval=4,
            use_gpu_pipeline=True,
        )
        scene: MultimodalDroneSceneCfg = MultimodalDroneSceneCfg(
            num_envs=64,
            env_spacing=8.0,
        )

        # Multimodal observation — passed as a dict
        # SB3 handles Dict obs spaces natively when using MultiInputPolicy
        observation_space = {
            "image":   (3, 84, 84),
            "sensors": (SensorLayout.N_SENSORS,),
        }
        action_space: int = 4

        episode_length_s: float = 10.0
        max_episode_steps: int  = 500

        # Reward shaping
        reward_approach:  float =  5.0
        reward_alive:     float =  0.1
        reward_reach:     float = 100.0
        penalty_crash:    float = -100.0
        penalty_boundary: float = -50.0

        # Sensor noise (domain randomized each episode)
        sensor_noise: SensorNoiseCfg = SensorNoiseCfg()
        enable_domain_rand: bool = True

except Exception:
    MultimodalDroneEnvCfg = None


# =============================================================================
# Sensor Normalizer  (runs on GPU — pure torch operations)
# =============================================================================
class SensorNormalizer:
    """
    Normalizes raw sensor readings to approximately [-1, 1] range
    and injects calibrated Gaussian noise.
    All operations are batched over num_envs on the GPU.
    """

    def __init__(self, cfg: SensorNoiseCfg, num_envs: int, device: str):
        self.cfg      = cfg
        self.num_envs = num_envs
        self.device   = device
        # Per-episode noise scale — randomized on every reset
        self._noise_scale = torch.ones(num_envs, 1, device=device)

    def randomize_noise(self, env_ids: torch.Tensor):
        """Call at episode reset to vary sensor quality across episodes."""
        self._noise_scale[env_ids] = torch.rand(
            len(env_ids), 1, device=self.device
        ) * (self.cfg.noise_scale_max - self.cfg.noise_scale_min) + self.cfg.noise_scale_min

    def _add_noise(self, tensor: torch.Tensor, std: float) -> torch.Tensor:
        noise = torch.randn_like(tensor) * std * self._noise_scale
        return tensor + noise

    def normalize_imu(
        self,
        linear_acc: torch.Tensor,   # (N, 3) m/s²
        angular_vel: torch.Tensor,  # (N, 3) rad/s
        quat: torch.Tensor,         # (N, 4) [qw, qx, qy, qz]
    ) -> torch.Tensor:
        acc_n   = self._add_noise(linear_acc,  self.cfg.accel_std) / SensorLayout.NORM["accel"]
        gyro_n  = self._add_noise(angular_vel, self.cfg.gyro_std)  / SensorLayout.NORM["gyro"]
        # Quaternion is already in [-1,1] — no normalization needed, just noise
        quat_n  = quat + torch.randn_like(quat) * 0.005 * self._noise_scale
        quat_n  = torch.nn.functional.normalize(quat_n, dim=-1)  # Re-normalize after noise
        return torch.cat([acc_n, gyro_n, quat_n], dim=-1)        # (N, 10)

    def normalize_baro(
        self,
        altitude: torch.Tensor,    # (N, 1) m
        vert_vel: torch.Tensor,    # (N, 1) m/s
    ) -> torch.Tensor:
        alt_n  = self._add_noise(altitude, self.cfg.baro_std) / SensorLayout.NORM["altitude"]
        vvel_n = self._add_noise(vert_vel, self.cfg.baro_std) / SensorLayout.NORM["vert_vel"]
        return torch.cat([alt_n, vvel_n], dim=-1)                # (N, 2)

    def normalize_airspeed(self, airspeed: torch.Tensor) -> torch.Tensor:
        return self._add_noise(airspeed, self.cfg.airspeed_std) / SensorLayout.NORM["airspeed"]  # (N, 1)

    def normalize_lidar(self, ranges: torch.Tensor) -> torch.Tensor:
        # Clip to max range, add noise, normalize
        ranges_clipped = torch.clamp(ranges, 0.0, 20.0)
        return self._add_noise(ranges_clipped, self.cfg.lidar_std) / SensorLayout.NORM["lidar"]  # (N, 8)

    def normalize_target(
        self,
        target_pos: torch.Tensor,  # (N, 3)
        drone_pos: torch.Tensor,   # (N, 3)
    ) -> torch.Tensor:
        delta = target_pos - drone_pos
        dist  = torch.norm(delta, dim=-1, keepdim=True).clamp(min=1e-6)
        direction = delta / dist                                 # unit vector (N, 3)
        dist_n    = dist / SensorLayout.NORM["target_dist"]
        return torch.cat([direction, dist_n], dim=-1)           # (N, 4)


# =============================================================================
# Multimodal Drone Environment
# =============================================================================
class MultimodalDroneEnv(DirectRLEnv if ISAAC_AVAILABLE else object):
    """
    Full multimodal drone environment.
    Returns a dict observation containing image + sensor vector at every step.
    """

    cfg: MultimodalDroneEnvCfg

    def __init__(self, cfg, **kwargs):
        super().__init__(cfg, **kwargs)

        self._normalizer = SensorNormalizer(
            cfg.sensor_noise, self.num_envs, self.device
        )

        # State tensors (GPU)
        self._drone_pos    = torch.zeros(self.num_envs, 3,  device=self.device)
        self._target_pos   = torch.zeros(self.num_envs, 3,  device=self.device)
        self._prev_dist    = torch.zeros(self.num_envs,     device=self.device)
        self._bounds       = torch.tensor([5.0, 5.0, 4.0],  device=self.device)

    # -------------------------------------------------------------------------
    # Scene setup
    # -------------------------------------------------------------------------
    def _setup_scene(self):
        self._drone  = Articulation(self.cfg.scene.drone)
        self._camera = Camera(self.cfg.scene.camera)
        self._imu    = Imu(self.cfg.scene.imu)
        self._lidar  = RayCaster(self.cfg.scene.lidar)

        self.scene.articulations["drone"]   = self._drone
        self.scene.sensors["camera"]        = self._camera
        self.scene.sensors["imu"]           = self._imu
        self.scene.sensors["lidar"]         = self._lidar

        sim_utils.add_ground_plane()
        self.scene.clone_environments(copy_from_source=False)
        self.scene.filter_collisions(global_prim_paths=[])

    # -------------------------------------------------------------------------
    # Multimodal observation construction
    # -------------------------------------------------------------------------
    def _get_observations(self) -> Dict[str, torch.Tensor]:
        """
        Assembles both observation streams on the GPU.
        The dict is consumed by MultimodalExtractor in multimodal_policy.py.
        """

        # ── Stream A: RGB Image ───────────────────────────────────────────
        rgba  = self._camera.data.output["rgb"]          # (N, H, W, 4) uint8
        image = rgba[..., :3].float() / 255.0            # Drop alpha, normalize
        image = image.permute(0, 3, 1, 2).contiguous()  # (N, 3, H, W)

        # ── Stream B: Sensor Vector ───────────────────────────────────────
        # Pull from Isaac Lab sensor data buffers (all GPU tensors)
        drone_state  = self._drone.data

        # IMU — Isaac Lab ImuData provides accelerometer and gyroscope
        linear_acc   = self._imu.data.lin_acc_b          # (N, 3) body frame
        angular_vel  = self._imu.data.ang_vel_b          # (N, 3) body frame
        quat         = drone_state.root_quat_w           # (N, 4) world frame

        # Barometer — derived from world-frame z position and velocity
        altitude     = drone_state.root_pos_w[:, 2:3]   # (N, 1)
        vert_vel     = drone_state.root_lin_vel_w[:, 2:3]  # (N, 1)

        # Airspeed — forward velocity in body frame
        lin_vel_body = quat_rotate_inverse(quat, drone_state.root_lin_vel_w)
        airspeed     = lin_vel_body[:, 0:1]              # (N, 1) forward

        # Lidar — RayCaster hit distances (8 beams, ~N, 8 after selection)
        lidar_raw    = self._get_lidar_ranges()          # (N, 8)

        # Navigation target
        self._drone_pos = drone_state.root_pos_w[:, :3]

        # Normalize and assemble
        imu_vec     = self._normalizer.normalize_imu(linear_acc, angular_vel, quat)  # (N, 10)
        baro_vec    = self._normalizer.normalize_baro(altitude, vert_vel)             # (N, 2)
        air_vec     = self._normalizer.normalize_airspeed(airspeed)                   # (N, 1)
        lidar_vec   = self._normalizer.normalize_lidar(lidar_raw)                     # (N, 8)
        target_vec  = self._normalizer.normalize_target(self._target_pos,
                                                         self._drone_pos)             # (N, 4)

        sensor_vector = torch.cat(
            [imu_vec, baro_vec, air_vec, lidar_vec, target_vec], dim=-1
        )  # (N, 25)

        assert sensor_vector.shape[1] == SensorLayout.N_SENSORS, \
            f"Sensor vector size mismatch: {sensor_vector.shape[1]} != {SensorLayout.N_SENSORS}"

        return {
            "image":   image,          # (N, 3, 84, 84)  float32 [0,1]
            "sensors": sensor_vector,  # (N, 25)          float32 normalized
        }

    def _get_lidar_ranges(self) -> torch.Tensor:
        """
        Extract 8 directional ranges from the RayCaster hit buffer.
        Returns (num_envs, 8) float tensor of distances in meters.
        """
        # RayCaster returns hit positions; compute distance from drone
        hit_points   = self._lidar.data.ray_hits_w       # (N, n_rays, 3)
        drone_pos    = self._drone_pos.unsqueeze(1)       # (N, 1, 3)
        distances    = torch.norm(hit_points - drone_pos, dim=-1)  # (N, n_rays)

        # Select 8 representative rays (fwd, back, left, right + diagonals)
        # The exact indices depend on your RayCaster pattern — tune these
        ray_indices = [0, 1, 2, 3, 4, 5, 6, 7]
        n_rays      = distances.shape[1]
        indices     = [min(i * (n_rays // 8), n_rays - 1) for i in range(8)]
        return distances[:, indices]                       # (N, 8)

    # -------------------------------------------------------------------------
    # Actions, Rewards, Termination — same as visual_drone_env.py
    # -------------------------------------------------------------------------
    def _pre_physics_step(self, actions: torch.Tensor):
        max_vel = torch.tensor([3.0, 3.0, 2.0, 1.5], device=self.device)
        forces  = (actions * max_vel)[:, :3] * 1.5
        self._drone.set_external_force_and_torque(
            forces=forces.unsqueeze(1),
            torques=torch.zeros_like(forces).unsqueeze(1),
        )

    def _apply_action(self):
        self._drone.write_data_to_sim()

    def _get_rewards(self) -> torch.Tensor:
        dist     = torch.norm(self._target_pos - self._drone_pos, dim=1)
        approach = (self._prev_dist - dist) * self.cfg.reward_approach
        alive    = torch.full((self.num_envs,), self.cfg.reward_alive, device=self.device)
        reached  = (dist < 0.3).float() * self.cfg.reward_reach
        crashed  = (self._drone_pos[:, 2] < 0.1).float() * abs(self.cfg.penalty_crash)
        self._prev_dist = dist
        return approach + alive + reached - crashed

    def _get_dones(self):
        terminated = (self._drone_pos[:, 2] < 0.1)
        terminated |= (self._drone_pos.abs() > self._bounds).any(dim=1)
        terminated |= torch.norm(self._target_pos - self._drone_pos, dim=1) < 0.3
        truncated   = self.episode_length_buf >= self.cfg.max_episode_steps
        return terminated, truncated

    def _reset_idx(self, env_ids: torch.Tensor):
        if len(env_ids) == 0:
            return

        # Randomize sensor noise level for this episode
        self._normalizer.randomize_noise(env_ids)

        # Randomize start and target positions
        start        = torch.zeros(len(env_ids), 3, device=self.device)
        start[:, :2] = torch.rand(len(env_ids), 2, device=self.device) * 2 - 1
        start[:, 2]  = torch.rand(len(env_ids), device=self.device) * 1.5 + 1.0

        self._target_pos[env_ids, :2] = torch.rand(len(env_ids), 2, device=self.device) * 6 - 3
        self._target_pos[env_ids,  2] = torch.rand(len(env_ids),    device=self.device) * 2 + 0.5

        default_state       = self._drone.data.default_root_state[env_ids].clone()
        default_state[:, :3] = start
        self._drone.write_root_state_to_sim(default_state, env_ids=env_ids)

        self._prev_dist[env_ids] = torch.norm(
            self._target_pos[env_ids] - start, dim=1
        )
        self._drone.reset(env_ids)
        super()._reset_idx(env_ids)


# =============================================================================
# TorchRL EnvBase Wrapper — GPU-native, TensorDict I/O (Multimodal)
# =============================================================================
try:
    from torchrl.envs import EnvBase
    from tensordict import TensorDict
    try:
        from torchrl.data import (
            CompositeSpec,
            BoundedTensorSpec,
            UnboundedContinuousTensorSpec,
        )
    except ImportError:
        from torchrl.data.tensor_specs import (
            Composite as CompositeSpec,
            Bounded as BoundedTensorSpec,
            UnboundedContinuous as UnboundedContinuousTensorSpec,
        )
    TORCHRL_AVAILABLE = True
except ImportError as exc:
    TORCHRL_IMPORT_ERROR = exc
    TORCHRL_AVAILABLE = False


class MultimodalDroneTorchRLWrapper(EnvBase if TORCHRL_AVAILABLE else object):
    """
    Wraps MultimodalDroneEnv as a TorchRL EnvBase environment.

    All tensors stay on GPU — no CPU/numpy roundtrip.
    Returns TensorDict with both image and sensor keys.

    Observations:
      td["image"]   → (num_envs, 3, 84, 84)  float32 [0,1]
      td["sensors"] → (num_envs, 25)          float32 normalized
    Action:
      td["action"]  → (num_envs, 4)           float32 [-1,1]
    """

    def __init__(self, isaac_env: "MultimodalDroneEnv", device=None, **kwargs):
        if not TORCHRL_AVAILABLE:
            raise ImportError("TorchRL is required for MultimodalDroneTorchRLWrapper") from TORCHRL_IMPORT_ERROR

        self._isaac_env = isaac_env
        _device = device or isaac_env.device
        super().__init__(
            device=_device,
            batch_size=torch.Size([isaac_env.num_envs]),
            **kwargs,
        )

        # ── Define specs ─────────────────────────────────────────────────
        H = W = 84
        batch_shape = torch.Size([isaac_env.num_envs])
        self.observation_spec = CompositeSpec(
            image=BoundedTensorSpec(
                low=0.0, high=1.0,
                shape=(*batch_shape, 3, H, W),
                dtype=torch.float32,
                device=_device,
            ),
            sensors=UnboundedContinuousTensorSpec(
                shape=(*batch_shape, SensorLayout.N_SENSORS),
                dtype=torch.float32,
                device=_device,
            ),
            shape=batch_shape,
        )
        self.action_spec = BoundedTensorSpec(
            low=-1.0, high=1.0,
            shape=(*batch_shape, 4),
            dtype=torch.float32,
            device=_device,
        )
        self.reward_spec = UnboundedContinuousTensorSpec(
            shape=(*batch_shape, 1),
            dtype=torch.float32,
            device=_device,
        )

    def _reset(self, tensordict=None, **kwargs) -> TensorDict:
        """
        Reset wrapper for TorchRL.

        TorchRL calls reset(select_reset_only=True) after done=True during
        collection. The IsaacLab DirectRLEnv has already handled per-env resets
        inside step(), so forcing another full self._isaac_env.reset() here can
        reset camera/sensor GPU buffers a second time and trigger CUDA illegal
        memory access.

        Full reset is used only for the initial reset. Selective TorchRL resets
        simply return the latest IsaacLab observation with done flags cleared.
        """
        select_reset_only = bool(kwargs.get("select_reset_only", False))

        if select_reset_only:
            obs_dict = self._isaac_env._get_observations()
        else:
            obs_dict, _ = self._isaac_env.reset()

        done_shape = (*self.batch_size, 1)
        zeros = torch.zeros(done_shape, dtype=torch.bool, device=self.device)

        return TensorDict(
            {
                "image":      obs_dict["image"],       # (N, 3, 84, 84)
                "sensors":    obs_dict["sensors"],     # (N, 25)
                "done":       zeros.clone(),
                "terminated": zeros.clone(),
                "truncated":  zeros.clone(),
            },
            batch_size=self.batch_size,
            device=self.device,
        )

    def _step(self, tensordict: TensorDict) -> TensorDict:
        actions = tensordict["action"]  # (N, 4) — already on GPU
        obs_dict, rewards, terminated, truncated, info = self._isaac_env.step(actions)

        done = (terminated | truncated).unsqueeze(-1)  # (N, 1)

        return TensorDict(
            {
                "image":      obs_dict["image"],              # (N, 3, 84, 84)
                "sensors":    obs_dict["sensors"],            # (N, 25)
                "reward":     rewards.unsqueeze(-1),          # (N, 1)
                "done":       done,
                "terminated": terminated.unsqueeze(-1),       # (N, 1)
                "truncated":  truncated.unsqueeze(-1),        # (N, 1)
            },
            batch_size=self.batch_size,
            device=self.device,
        )

    def _set_seed(self, seed: int | None):
        # Isaac Lab handles seeding internally via SimulationCfg
        pass

    def close(self):
        self._isaac_env.close()
