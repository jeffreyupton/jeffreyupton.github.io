#!/usr/bin/env bash
set -euo pipefail

echo "==> Stopping old containers"
docker compose down --remove-orphans || true

echo "==> Removing old image tags"
docker image rm drone-rl:latest drone-rl:isaac51-lab230 2>/dev/null || true

echo "==> Optional builder cleanup"
docker builder prune -f

echo "==> Building fixed Isaac image"
docker compose build --no-cache isaac_sim

echo "==> Checking GPU visibility inside container"
docker compose run --rm isaac_sim bash -lc '
set -e
echo "--- nvidia-smi ---"
nvidia-smi

echo "--- libcuda ---"
ldconfig -p | grep libcuda || true

echo "--- CUDA stubs check ---"
if echo "$LD_LIBRARY_PATH" | tr ":" "\n" | grep -i "cuda.*/stubs"; then
  echo "ERROR: CUDA stubs found in LD_LIBRARY_PATH. Remove them before training."
  exit 1
else
  echo "OK: no CUDA stubs in LD_LIBRARY_PATH"
fi

echo "--- torch cuda check ---"
/isaac-sim/python.sh - <<PY
import torch
print("torch:", torch.__version__)
print("cuda build:", torch.version.cuda)
print("cuda available:", torch.cuda.is_available())
print("gpu:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "none")
PY
'

echo "==> Starting small training smoke test"
docker compose up isaac_sim
